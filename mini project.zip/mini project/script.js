const quoteDisplay = document.getElementById("quote");
const typingArea = document.getElementById("typingArea");
const startButton = document.getElementById("startButton");
const resetButton = document.getElementById("resetButton");
const wpmDisplay = document.getElementById("wpm");
const cpmDisplay = document.getElementById("cpm");
const timeDisplay = document.getElementById("time");
const accuracyDisplay = document.getElementById("accuracy");

document.body.style.display = "flex";
document.body.style.justifyContent = "center";
document.body.style.alignItems = "center";
document.body.style.height = "100vh";
document.body.style.flexDirection = "column";
document.body.style.textAlign = "center";
document.body.style.fontSize = "1.5em";

typingArea.style.border = "2px solid white";
typingArea.style.fontSize = "1.2em";

let timer;
let timeLeft = 60;
let totalTyped = 0;
let correctTyped = 0;
let errors = 0;
let isRunning = false;
let quote = "";

const quotes = [
    "Success is not final, failure is not fatal: it is the courage to continue that counts.",
    "The only limit to our realization of tomorrow is our doubts of today.",
    "The future belongs to those who believe in the beauty of their dreams.",
    "It does not matter how slowly you go as long as you do not stop.",
    "Dream big and dare to fail.",
    "The best way to predict the future is to create it."
];

function getNewQuote() {
    quote = quotes[Math.floor(Math.random() * quotes.length)];
    quoteDisplay.innerText = quote;
}

function startTest() {
    if (isRunning) return;
    isRunning = true;
    timeLeft = 60;
    totalTyped = 0;
    correctTyped = 0;
    errors = 0;
    typingArea.disabled = false;
    typingArea.value = "";
    typingArea.focus();
    getNewQuote();
    timer = setInterval(updateTime, 1000);
}

function resetTest() {
    clearInterval(timer);
    isRunning = false;
    typingArea.value = "";
    typingArea.disabled = true;
    quoteDisplay.innerText = "Press Start to Begin";
    timeLeft = 60;
    totalTyped = 0;
    correctTyped = 0;
    errors = 0;
    wpmDisplay.innerText = "0";
    cpmDisplay.innerText = "0";
    accuracyDisplay.innerText = "100";
    timeDisplay.innerText = "60";
    document.body.classList.remove("time-warning");
    document.body.style.background = "url('https://source.unsplash.com/1600x900/?dark,abstract') no-repeat center center/cover";
    typingArea.style.border = "2px solid white";
}

function updateTime() {
    if (timeLeft <= 0) {
        clearInterval(timer);
        typingArea.disabled = true;
        isRunning = false;
        document.body.classList.remove("time-warning");
        getNewQuote();
        return;
    }
    timeLeft--;
    timeDisplay.innerText = timeLeft;
    if (timeLeft <= 10) {
        document.body.classList.add("time-warning");
    }
}

typingArea.addEventListener("input", () => {
    const typedText = typingArea.value;
    totalTyped = typedText.length;
    errors = 0;
    correctTyped = 0;
    
    let displayText = "";
    let hasError = false;
    for (let i = 0; i < quote.length; i++) {
        if (i < typedText.length) {
            if (typedText[i] === quote[i]) {
                displayText += `<span>${quote[i]}</span>`;
                correctTyped++;
            } else {
                displayText += `<span class='highlight-wrong'>${quote[i]}</span>`;
                errors++;
                hasError = true;
            }
        } else {
            displayText += quote[i];
        }
    }
    quoteDisplay.innerHTML = displayText;
    
    let accuracy = totalTyped > 0 ? ((correctTyped / totalTyped) * 100).toFixed(1) : 100;
    let wpm = ((correctTyped / 5) / ((60 - timeLeft) / 60)).toFixed(1);
    let cpm = (correctTyped / ((60 - timeLeft) / 60)).toFixed(1);
    
    wpmDisplay.innerText = isNaN(wpm) ? "0" : wpm;
    cpmDisplay.innerText = isNaN(cpm) ? "0" : cpm;
    accuracyDisplay.innerText = accuracy;
    
    if (hasError) {
        document.body.style.background = "url('https://source.unsplash.com/1600x900/?red,abstract') no-repeat center center/cover";
        typingArea.style.border = "2px solid red";
    } else {
        document.body.style.background = "url('https://source.unsplash.com/1600x900/?dark,abstract') no-repeat center center/cover";
        typingArea.style.border = "2px solid white";
    }

    if (typedText.length === quote.length && typedText === quote) {
        getNewQuote();
        typingArea.value = "";
    }
});

startButton.addEventListener("click", startTest);
resetButton.addEventListener("click", resetTest);

resetTest();
